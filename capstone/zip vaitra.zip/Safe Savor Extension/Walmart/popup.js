document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("saveButton").addEventListener("click", storeAllergen);
    document.getElementById("resetButton").addEventListener("click", resetAllergens);
    document.getElementById("websiteButton").addEventListener("click", visitWebsite);
    loadAllergens();
});

// ✅ Store Allergen
function storeAllergen() {
    const allergen = document.getElementById("allergenInput").value.trim();
    if (allergen) {
        chrome.storage.local.get("allergens", (result) => {
            const allergens = result.allergens || [];
            if (!allergens.includes(allergen)) {
                allergens.push(allergen);
                chrome.storage.local.set({ allergens }, () => {
                    document.getElementById("statusMessage").innerText = "Allergen saved!";
                    loadAllergens();
                    document.getElementById("allergenInput").value = "";
                });
            } else {
                document.getElementById("statusMessage").innerText = "Allergen already exists!";
            }
        });
    } else {
        document.getElementById("statusMessage").innerText = "Please enter an allergen.";
    }
}

// ✅ Load Allergens
function loadAllergens() {
    chrome.storage.local.get("allergens", (result) => {
        const allergens = result.allergens || [];
        document.getElementById("statusMessage").innerText = allergens.length > 0 
            ? "Stored Allergens: " + allergens.join(", ")
            : "No allergens found.";
    });
}

// ✅ Reset Allergens
function resetAllergens() {
    chrome.storage.local.remove("allergens", () => {
        document.getElementById("statusMessage").innerText = "Allergens cleared.";
        loadAllergens();
    });
}

// ✅ Visit Website (Fixed to avoid localhost CSP issues)
function visitWebsite() {
    // Option 1: Use a proper domain instead of localhost
    // chrome.tabs.create({ url: "https://your-website.com" });
    
    // Option 2: For development, create a local HTML file
    chrome.tabs.create({ url: chrome.runtime.getURL("website.html") });
    
    // Option 3: If you must use localhost, do it differently
    // chrome.tabs.create({ url: "http://localhost:5500/index.html" });
}
